import json
import os
from datetime import datetime
import base64
import gzip
import pymysql
from pymysql.err import OperationalError


# Configuración de conexión a MySQL RDS (Variables de entorno)
MYSQL_HOST = os.getenv("MYSQL_HOST")
MYSQL_USER = os.getenv("MYSQL_USER", "admin")
MYSQL_PASSWORD = os.getenv("MYSQL_PASSWORD")
MYSQL_DATABASE = os.getenv("MYSQL_DATABASE", "my_database")


def parse_cloudwatch_log(event):
    """Parses a CloudWatch Logs event and extracts relevant data."""
    try:
        compressed_payload = base64.b64decode(event['awslogs']['data'])
        log_payload = gzip.decompress(compressed_payload)
        log_data = json.loads(log_payload)


        log_events = log_data.get('logEvents', [])
        documents = []


        for log_event in log_events:
            message = log_event.get('message', '')
            if 'Documento generado:' in message:
                start_index = message.find('{')
                raw_document = message[start_index:]
                raw_document = raw_document.strip()
                raw_document = raw_document.replace("'", '"')
                raw_document = raw_document.replace("False", "false").replace("True", "true")


                try:
                    document_data = json.loads(raw_document)
                    documents.append(document_data)
                    print(documents)
                except json.JSONDecodeError as e:
                    print(f"Error al parsear JSON: {e}")
                    continue


        return documents
    except Exception as e:
        print(f"Error al parsear el log de CloudWatch: {str(e)}")
        return []


def lambda_handler(event, context):
    try:
        connection = pymysql.connect(
            host=MYSQL_HOST,
            user=MYSQL_USER,
            password=MYSQL_PASSWORD,
            database=MYSQL_DATABASE,
            cursorclass=pymysql.cursors.DictCursor
        )
        print("Conectado a MySQL")
    except OperationalError as e:
        print("Conexion fallida")
        return {
            "statusCode": 500,
            "body": f"Error conectando a MySQL: {str(e)}"
        }


    documents = parse_cloudwatch_log(event)
    if not documents:
        print("No hay documentos validos")
        return {
            "statusCode": 400,
            "body": "No se encontraron documentos válidos en los logs"
        }


    try:
        with connection.cursor() as cursor:
            for document in documents:
                # Insertar el diario
                cursor.execute(
                    """
                    INSERT INTO diarios (_id, fecha, url_imagen, usuario_uuid, descripcion, emoticono)
                    VALUES (%s, %s, %s, %s, %s, %s)
                    """,
                    (
                        document["_id"],
                        document["fecha"],
                        document["url_imagen"],
                        document["usuario"],
                        document["descripcion"],
                        document["emoticono"]
                    )
                )


            # Confirmar transacciones
            connection.commit()
        print("Exito insertando el documento")


        return {
            "statusCode": 200,
            "body": {"usuario": document["usuario"], "mensaje": "Documento insertado exitosamente"}
        }
    except Exception as e:
        connection.rollback()
        print(f"Error insertando documentos: {str(e)}")
        return {
            "statusCode": 500,
            "body": f"Error insertando documentos: {str(e)}"
        }
    finally:
        print("cerrando conexion")
        connection.close()
