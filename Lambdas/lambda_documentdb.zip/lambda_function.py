import json
import os
from datetime import datetime
from pymongo import MongoClient
from pymongo.errors import ConnectionFailure
import base64
import gzip

# Conexión con DocumentDB (Variables de entorno)
MONGO_URI = os.getenv("MONGO_URI")  # URI de DocumentDB
DATABASE_NAME = os.getenv("DATABASE_NAME", "my_database")
COLLECTION_NAME = os.getenv("COLLECTION_NAME", "documents")

# Inicializar cliente MongoDB
client = MongoClient(MONGO_URI, tls=True)

def parse_cloudwatch_log(event):
    """Parses a CloudWatch Logs event and extracts relevant data."""
    try:
        # Los logs vienen codificados en base64 y comprimidos con gzip
        compressed_payload = base64.b64decode(event['awslogs']['data'])
        log_payload = gzip.decompress(compressed_payload)
        log_data = json.loads(log_payload)

        # Extraer mensajes individuales de log
        log_events = log_data.get('logEvents', [])
        documents = []

        for log_event in log_events:
            message = log_event.get('message', '')
            print(message)
            if 'Documento generado:' in message:
                # Extraer el JSON del documento generado
                start_index = message.find('{')
                raw_document = message[start_index:]
                
                # Limpieza y preparación del JSON
                raw_document = raw_document.strip()  # Elimina espacios al principio y final
                raw_document = raw_document.replace("'", '"')  # Cambiar comillas simples por dobles
                raw_document = raw_document.replace("False", "false").replace("True", "true")  # JSON usa `true/false`
                print(raw_document)

                try:
                    # Intentar cargar el JSON
                    document_data = json.loads(raw_document)
                    documents.append(document_data)
                except json.JSONDecodeError as e:
                    print(f"Error al parsear JSON: {e}")
                    continue

        return documents
    except Exception as e:
        print(f"Error al parsear el log de CloudWatch: {str(e)}")
        return []



def lambda_handler(event, context):
    try:
        # Validar conexión a DocumentDB
        client.admin.command('ping')
    except ConnectionFailure as e:
        return {
            "statusCode": 500,
            "body": f"Error conectando a DocumentDB: {str(e)}"
        }
    
    # Procesar logs de CloudWatch
    documents = parse_cloudwatch_log(event)
    if not documents:
        return {
            "statusCode": 400,
            "body": "No se encontraron documentos válidos en los logs"
        }
    
    try:
        # Insertar cada documento en DocumentDB
        db = client[DATABASE_NAME]
        collection = db[COLLECTION_NAME]
        
        inserted_ids = []
        for document in documents:
            # Agregar fecha de inserción
            document["inserted_at"] = datetime.utcnow().isoformat()
            result = collection.insert_one(document)
            print("Documento insertado")
            inserted_ids.append(str(result.inserted_id))
        
        return {
            "statusCode": 200,
            "body": {
                "message": "Documentos insertados exitosamente",
                "inserted_ids": inserted_ids
            }
        }
    except Exception as e:
        return {
            "statusCode": 500,
            "body": f"Error insertando documentos: {str(e)}"
        }
