import boto3
import os
import datetime
import uuid
from concurrent.futures import ThreadPoolExecutor, TimeoutError

# Inicialización de clientes persistentes
s3_client = boto3.client('s3')
rekognition_client = boto3.client('rekognition')
translate_client = boto3.client('translate')
comprehend_client = boto3.client('comprehend')

# Variables de entorno
S3_BUCKET = os.environ.get('S3_BUCKET')

if not S3_BUCKET:
    raise ValueError("Faltan variables de entorno necesarias")

def lambda_handler(event, context):
    try:
        print(f"Evento recibido: {event}")

        # Validación del evento
        record = event['Records'][0]  # Solo procesamos el primer registro por simplicidad
        s3_key = record['s3']['object']['key']

        if not s3_key:
            raise ValueError("Clave 's3_key' no encontrada en el evento")

        # Validar tamaño de la imagen antes de procesar
        validate_image(S3_BUCKET, s3_key)

        # Construir la URL de la imagen
        usuario = s3_key.split('/')[0]
        url_imagen = f"https://{S3_BUCKET}.s3.amazonaws.com/{s3_key}"
        print(f"URL de imagen generada: {url_imagen}")

        # Ejecutar análisis en paralelo con tiempos límite
        labels = emotions_response = contenido_inapropiado = None
        with ThreadPoolExecutor() as executor:
            try:
                print("Iniciando análisis en paralelo...")
                future_labels = executor.submit(detect_labels, s3_key)
                future_emotions = executor.submit(detect_emotions, s3_key)
                future_moderation = executor.submit(detect_moderation, s3_key)

                labels = future_labels.result(timeout=30)  # Máximo 30s
                emotions_response = future_emotions.result(timeout=30)
                contenido_inapropiado = future_moderation.result(timeout=30)
            except TimeoutError as e:
                print(f"Timeout en una de las tareas paralelas: {e}")
                labels = labels or []
                emotions_response = emotions_response or {"FaceDetails": []}
                contenido_inapropiado = contenido_inapropiado or False

        # Generar descripción y emoticono
        descripcion = generate_description_from_labels(labels)
        emoticono = assign_emoticon(labels, emotions_response)
        print(f"Descripción generada: {descripcion}")
        print(f"Emoticono asignado: {emoticono}")

        # Crear respuesta
        document = {
            "_id": str(uuid.uuid4()),
            "fecha": datetime.datetime.now().strftime("%d/%m/%y"),
            "url_imagen": url_imagen,
            "usuario": usuario,
            "descripcion": descripcion,
            "emoticono": emoticono,
            "contenido_inapropiado": contenido_inapropiado
        }
        print(f"Documento generado: {document}")

        return {"status": "success", "document": document}

    except Exception as e:
        print(f"Error: {e}")
        return {"status": "error", "message": str(e)}

# Funciones auxiliares

def validate_image(bucket, key):
    """Valida el tamaño y formato de la imagen antes de procesarla."""
    print(f"Validando imagen: Bucket={bucket}, Key={key}")
    response = s3_client.head_object(Bucket=bucket, Key=key)
    size_in_mb = response['ContentLength'] / (1024 * 1024)
    if size_in_mb > 10:  # Máximo 10 MB
        raise ValueError(f"Imagen demasiado grande: {size_in_mb:.2f} MB")
    print("Imagen validada correctamente")

def detect_labels(s3_key):
    """Detecta etiquetas en la imagen usando Rekognition."""
    print(f"Detectando etiquetas para la clave S3: {s3_key}")
    response = rekognition_client.detect_labels(
        Image={'S3Object': {'Bucket': S3_BUCKET, 'Name': s3_key}},
        MaxLabels=10
    )
    labels = [label['Name'] for label in response['Labels']]
    print(f"Etiquetas detectadas: {labels}")
    return labels

def detect_emotions(s3_key):
    """Detecta emociones en caras usando Rekognition."""
    print(f"Detectando emociones para la clave S3: {s3_key}")
    response = rekognition_client.detect_faces(
        Image={'S3Object': {'Bucket': S3_BUCKET, 'Name': s3_key}},
        Attributes=['ALL']
    )
    print(f"Respuesta de emociones: {response}")
    return response

def detect_moderation(s3_key):
    """Detecta etiquetas de contenido inapropiado."""
    print(f"Detectando contenido inapropiado para la clave S3: {s3_key}")
    response = rekognition_client.detect_moderation_labels(
        Image={'S3Object': {'Bucket': S3_BUCKET, 'Name': s3_key}},
        MinConfidence=70
    )
    contenido_inapropiado = len(response['ModerationLabels']) > 0
    print(f"¿Contenido inapropiado detectado?: {contenido_inapropiado}")
    return contenido_inapropiado

def assign_emoticon(labels, emotions_response):
    """Determina el emoticono basado en emociones o etiquetas."""
    print("Asignando emoticono...")
    if emotions_response['FaceDetails']:
        emotions = emotions_response['FaceDetails'][0]['Emotions']
        dominant_emotion = max(emotions, key=lambda x: x['Confidence'])['Type']
        return emotion_to_emoticon(dominant_emotion)

    for label in labels:
        emoticon = label_to_emoticon(label)
        if emoticon:
            return emoticon

    return "❓"

def emotion_to_emoticon(emotion):
    """Convierte emociones de Rekognition a emoticonos."""
    emotion_map = {
        "HAPPY": "😁", "SAD": "😢", "ANGRY": "😡", "CONFUSED": "🫠",
        "DISGUSTED": "😬", "SURPRISED": "😲", "CALM": "😌", "FEAR": "😨"
    }
    return emotion_map.get(emotion.upper(), ":|")

def label_to_emoticon(label):
    """Mapea etiquetas a emoticonos representativos."""
    label_map = {
        "Landscape": "🏞️", "Food": "🍕", "Animal": "🐾", "Person": "👤",
        "Vehicle": "🚗", "Sport": "⚽", "Building": "🏢", "Art": "🎨",
        "Plant": "🌱", "Beach": "🏖️", "Mountain": "🏔️", "Water": "💧"
    }
    return label_map.get(label, None)

def generate_description_from_labels(labels, date=None):
    """
    Genera una entrada de diario personalizada en español basada en etiquetas detectadas.
    """
    print("Generando entrada de diario...")
    if not labels:
        return "Hoy no se detectaron actividades destacadas."

    # Usar la fecha proporcionada o la fecha actual
    if not date:
        date = datetime.datetime.now().strftime("%d de %B de %Y")

    # Construir frases basadas en etiquetas detectadas
    spanish_phrases = []
    label_mapping = {
        "Beach": "visité una playa",
        "Sun": "disfruté de un día soleado",
        "Cloud": "observé un cielo nublado",
        "Mountain": "estuve en las montañas",
        "Water": "me acerqué a un cuerpo de agua",
        "Tree": "estuve rodeado(a) de árboles",
        "Flower": "vi flores hermosas",
        "Person": "estuve con alguien especial",
        "Animal": "me encontré con animales",
        "Vehicle": "viajé en un vehículo",
        "Food": "comí algo delicioso",
        "Building": "exploré un edificio interesante",
        "Art": "admiré arte",
        "Sport": "practiqué algún deporte",
        # Agregar más etiquetas aquí según sea necesario
    }

    # Combinaciones especiales para actividades específicas
    special_combinations = {
        frozenset(["Beach", "Sun"]): "disfruté de una playa soleada",
        frozenset(["Beach", "Cloud"]): "paseé por una playa nublada",
        frozenset(["Mountain", "Cloud"]): "exploré montañas entre nubes",
        frozenset(["Water", "Sun"]): "observé cómo el sol brillaba sobre el agua",
        # Agregar más combinaciones aquí según sea necesario
    }

    # Buscar combinaciones especiales
    detected_labels_set = frozenset(labels)
    for combination, phrase in special_combinations.items():
        if combination.issubset(detected_labels_set):
            spanish_phrases.append(phrase)
            detected_labels_set -= combination  # Evitar redundancia

    # Agregar etiquetas individuales restantes
    for label in detected_labels_set:
        if label in label_mapping:
            spanish_phrases.append(label_mapping[label])

    # Generar la entrada de diario
    description_spanish = f"El {date}, " + ", ".join(spanish_phrases) + "."
    print(f"Entrada de diario generada: {description_spanish}")
    return description_spanish