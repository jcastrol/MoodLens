import boto3
import pymysql
import os

# Configuración desde variables de entorno
DB_HOST = os.environ['DB_HOST']          # Dirección del endpoint de la base de datos RDS MySQL
DB_USER = os.environ['DB_USER']          # Usuario de la base de datos
DB_PASSWORD = os.environ['DB_PASSWORD']  # Contraseña de la base de datos
DB_NAME = os.environ['DB_NAME']          # Nombre de la base de datos

def lambda_handler(event, context):
    """
    Lambda que se ejecuta tras la confirmación de un usuario en Cognito.
    Inserta los datos del usuario en la tabla `usuarios` en MySQL.
    """
    print(f"Evento recibido: {event}")

    # Datos del usuario desde Cognito
    try:
        user_attributes = event['request']['userAttributes']
        uuid = user_attributes['sub']  # ID único del usuario generado por Cognito
        name = user_attributes.get('name', 'Nombre no proporcionado')
        lastname = user_attributes.get('family_name', 'Apellido no proporcionado')
        email = user_attributes['email']
        
        # Contraseña no se guarda directamente; usa un valor seguro o un placeholder si es necesario
        password = "hashed-password-placeholder"  

        # Conectar a la base de datos MySQL
        connection = pymysql.connect(
            host=DB_HOST,
            user=DB_USER,
            password=DB_PASSWORD,
            database=DB_NAME,
            charset='utf8mb4',
            cursorclass=pymysql.cursors.DictCursor
        )

        try:
            with connection.cursor() as cursor:
                # Query SQL para insertar en la tabla `usuarios`
                sql = """
                    INSERT INTO usuarios (uuid, name, lastname, email, password)
                    VALUES (%s, %s, %s, %s, %s)
                    ON DUPLICATE KEY UPDATE
                    name = VALUES(name),
                    lastname = VALUES(lastname),
                    email = VALUES(email);
                """
                cursor.execute(sql, (uuid, name, lastname, email, password))
                connection.commit()
                print(f"Usuario {uuid} añadido o actualizado en la tabla `usuarios`.")
        except Exception as e:
            print(f"Error al ejecutar el query SQL: {e}")
            raise
        finally:
            connection.close()
    except KeyError as e:
        print(f"Error al extraer atributos del evento: {e}")
        raise
    except Exception as e:
        print(f"Error general en la Lambda: {e}")
        raise

    print("Usuario añadido exitosamente")
    return event
